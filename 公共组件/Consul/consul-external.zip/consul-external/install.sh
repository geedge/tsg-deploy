#!/bin/bash

rm -rf /usr/lib/systemd/system/consul*service
rm -rf /usr/lib/systemd/system/consul*service
rm -rf /var/consul*
#cp -f /opt/consul-external/etc/systemd/consul-client.service /usr/lib/systemd/system/consul-client-external.service
cp -f /opt/consul-external/etc/systemd/consul-server.service /usr/lib/systemd/system/consul-server-external.service

ln -sf /opt/consul-B/script/consul_path_setup.sh /etc/profile.d/
systemctl daemon-reload
echo "systemctl start consul-server-external.service" >>/etc/rc.d/rc.local
chmod 755 /etc/rc.d/rc.local



